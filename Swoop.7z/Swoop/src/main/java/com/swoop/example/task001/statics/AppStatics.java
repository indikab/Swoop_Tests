package com.swoop.example.task001.statics;

public class AppStatics {
  public static String ERR_NULL_OBJ = "ERR_NULL_OBJ";
  public static String ERR_BAD_OP = "ERR_BAD_OP";
  public static String ERR_P1_001 = "ERR_P1_001";
  public static String ERR_P2_001 = "ERR_P2_001";
  public static String ERR_P1_002 = "ERR_P1_002";
  public static String ERR_P2_002 = "ERR_P2_002";
  
  public static String ERR_TYPE_SITA_EX = "ERR_TYPE_SITA_EX";
  public static String ERR_TYPE_JAVA_EX = "ERR_TYPE_JAVA_EX";
  public static String ERR_TYPE_COMM_EX = "ERR_TYPE_COMM_EX";
  
  public static String STS_SUCCESS = "STS_SUCCESS";
  public static String STS_FAILED = "STS_FAILED";
  
  public static String MATH_OP_ADD = "ADD";
  
  public static String X_API_KEY = "123123123123";
}
