package com.swoop.example.task001.services;

import org.springframework.stereotype.Service;

//Service class to perform DB activities in future.
@Service
public class DBAccess {
 
}
